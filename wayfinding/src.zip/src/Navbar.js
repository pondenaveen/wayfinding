import React from 'react';
import './Navbar.css';
import '@fortawesome/fontawesome-free/css/all.min.css';

import AccountCircleIcon from '@mui/icons-material/AccountCircle'; // Profile icon
import HomeIcon from '@mui/icons-material/Home'; // Example center icon

function Navbar() {
  return (
    <nav className="navbar" style={{ display: 'grid', gridTemplateColumns: 'auto 1fr auto', gridTemplateAreas: '"logo center profile"', alignItems: 'center', padding: '10px 20px', backgroundColor: 'white', boxShadow: '0px 2px 10px rgba(0, 0, 0, 0.1)' }}>

      {/* Logo Section */}
      <div className="navbar-logo" style={{ gridArea: 'logo', display: 'flex', justifyContent: 'flex-start' }}>
        <img src="/4CT.png" alt="Logo 2" style={{ height: '30px' }} />
      </div>

      {/* Center Icon Section */}
      <div className="navbar-center" style={{ gridArea: 'center', display: 'flex', justifyContent: 'center' }}>
        <img src="/sdt.png" alt="Logo 3" style={{ height: '50px' }} />
      </div>

      {/* Profile Section */}
      <div className="navbar-profile" style={{ gridArea: 'profile', display: 'flex', flexDirection: 'column', alignItems: 'flex-end' }}>
        <div style={{ display: 'flex', alignItems: 'center' }}>
          <AccountCircleIcon style={{ color: '#17a2b8', marginRight: '10px', fontSize: '40px' }} />
          <span className="navbar-welcome-message" style={{ fontSize: '16px', fontWeight: 'bold' }}>Hello, Admin</span>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
