import React from 'react';
import { styled } from '@mui/material/styles';
import fire from './images/exit copy.png';

const OuterGradientWrapper = styled('div')({
    backgroundColor: '#282e46',
    borderRadius: '50%',
    width: '50px',
    height: '50px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    cursor: 'pointer',
    margin: '0 auto', 
});

const Fire = ({ title, onClick }) => {
    const handleClick = () => {
        if (onClick) {
            onClick();
        }
    };

    return (
        <OuterGradientWrapper onClick={handleClick}>
            <img
                src={fire}
                alt="Fire Exit Icon"
                style={{
                    width: '32px',
                    height: '32px',
                    objectFit: 'contain',
                }}
            />
        </OuterGradientWrapper>
    );
};

export default Fire;
